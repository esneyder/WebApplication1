PageDown-Bootstrap
==================

This is a fork of http://code.google.com/p/pagedown/ changed to use Twitter Bootstrap for styling the editor and modal popups.

The demo is viewable here: http://samwillis.co.uk/pagedown-bootstrap/demo/browser/demo.html

New icons based on http://glyphicons.com/, http://dribbble.com/shots/365544-Mini-glyphs-12-px-Free-PSD and the origional icons.
